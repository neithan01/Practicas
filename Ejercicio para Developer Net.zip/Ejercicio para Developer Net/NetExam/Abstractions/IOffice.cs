﻿namespace NetExam.Abstractions
{
    public interface IOffice
    {
        string LocationName { get; }
        string Name { get; }
    }
}